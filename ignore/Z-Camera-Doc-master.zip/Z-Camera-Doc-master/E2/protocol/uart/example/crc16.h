#ifndef _CRC16_H_
#define _CRC16_H_



unsigned short crc16(unsigned short crc, unsigned char const *buffer, size_t len);


#endif // _CRC16_H_
