|  Pin   | Definition  |
|  ----  | ----  |
| 2      | TX_RS232 (Output from camera) |
| 3      | RX_RS232 |
| 6      | TX_TTL (Output from camera) |
| 9      | RX_TTL |