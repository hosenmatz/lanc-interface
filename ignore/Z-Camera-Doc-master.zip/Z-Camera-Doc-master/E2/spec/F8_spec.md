## Resolution & Framerate

| Resolution             |   Mmaximum fps  |
| :-                     |   :-:           |
| 8192x3456 8K DCI 2.4:1 |  30             |
| 7680x4320 8K UHD       |  30             |
| 6144x3240 6K DCI       |  30             |
| 5760x3240 6K UHD       |  30             |
| 3840x2160 4K UHD       |  60             |
| 3392x1908 S16 16:9     |  60             |

## Native ISO

| Mode  | value |
| :---  | :---: |
| Low   | 400   |
| High  | 1250  |

Maximum ISO without digital gain : 64000