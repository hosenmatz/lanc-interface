## Resolution & Framerate

| Resolution                   | Maximum fps         |
| :-----------:                | :-----------------: |
| 4096x2160 C4K DCI            | 30                  |
| 3840x2160 4K UHD             | 30                  |
| 3536x2092 S16                | 30                  |
| 2488x1400                    | 60                  |
| 1920x1080                    | 120                 |

## Native ISO

| Mode  | value |
| :---  | :---: |
| Low   | 1250   |

Maximum ISO without digital gain : 20000