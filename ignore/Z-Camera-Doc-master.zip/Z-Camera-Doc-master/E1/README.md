# Z Camera
  * HTTP API to build a new App for iOS/Android, PC as well.
  * UART command control. (You need a cable for expansion port)
